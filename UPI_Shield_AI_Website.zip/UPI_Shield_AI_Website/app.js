const $ = (id) => document.getElementById(id);
const homeScreen = $("homeScreen"), uploadScreen = $("uploadScreen"), resultScreen = $("resultScreen");
let selectedFile = null, extractedText = "", reportData = null;

function showScreen(screen) {
  [homeScreen, uploadScreen, resultScreen].forEach(s => s.classList.remove("active"));
  screen.classList.add("active");
  window.scrollTo({top: 0, behavior: "smooth"});
}
$("getStarted").addEventListener("click", () => showScreen(uploadScreen));
$("backHome").addEventListener("click", () => showScreen(homeScreen));
$("brandHome").addEventListener("click", e => { e.preventDefault(); showScreen(homeScreen); });
$("backUpload").addEventListener("click", () => showScreen(uploadScreen));
$("newReview").addEventListener("click", () => { clearFile(); showScreen(uploadScreen); });

function setProgress(message) { $("progressText").textContent = message; }
function clearFile() {
  selectedFile = null; extractedText = ""; reportData = null;
  $("fileInput").value = ""; $("previewWrap").classList.add("hidden");
  $("dropzone").classList.remove("hidden"); $("analyseButton").disabled = true;
  setProgress("");
}
function acceptFile(file) {
  if (!file) return;
  if (!file.type.startsWith("image/")) { alert("Please choose an image file."); return; }
  if (file.size > 10 * 1024 * 1024) { alert("File is larger than 10 MB. Please choose a smaller image."); return; }
  selectedFile = file;
  $("imagePreview").src = URL.createObjectURL(file);
  $("fileMeta").textContent = `${file.name} • ${(file.size / 1024).toFixed(0)} KB`;
  $("previewWrap").classList.remove("hidden");
  $("dropzone").classList.add("hidden");
  $("analyseButton").disabled = false;
  setProgress("");
}
$("fileInput").addEventListener("change", e => acceptFile(e.target.files[0]));
$("removeImage").addEventListener("click", clearFile);
const dz = $("dropzone");
dz.addEventListener("dragover", e => { e.preventDefault(); dz.classList.add("dragover"); });
dz.addEventListener("dragleave", () => dz.classList.remove("dragover"));
dz.addEventListener("drop", e => { e.preventDefault(); dz.classList.remove("dragover"); acceptFile(e.dataTransfer.files[0]); });

function extractAmount(text) {
  const patterns = [
    /(?:₹|INR|Rs\.?\s*)\s?([0-9,]+(?:\.\d{1,2})?)/i,
    /(?:amount|paid|payment|sent)\s*(?:of|:|-)?\s*(?:₹|INR|Rs\.?\s*)?\s?([0-9,]+(?:\.\d{1,2})?)/i
  ];
  for (const p of patterns) { const m = text.match(p); if (m) return "₹" + m[1].replace(/,/g, ""); }
  return "Not detected";
}
function extractDate(text) {
  const m = text.match(/\b(?:\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}|\d{4}[\/.-]\d{1,2}[\/.-]\d{1,2})\b/);
  return m ? m[0] : "Not detected";
}
function extractReference(text) {
  const lines = text.split(/\n/);
  for (let i=0;i<lines.length;i++) {
    if (/(upi\s*(ref|txn|transaction)|transaction\s*(id|no|number|ref)|utr|reference\s*(id|no|number))/i.test(lines[i])) {
      const value = lines[i].replace(/.*?(upi\s*(ref|txn|transaction)|transaction\s*(id|no|number|ref)|utr|reference\s*(id|no|number))\s*[:#\-]?\s*/i,"").trim();
      if (value.length > 2) return value.slice(0,60);
      if (lines[i+1] && lines[i+1].trim()) return lines[i+1].trim().slice(0,60);
    }
  }
  const generic = text.match(/\b[A-Z0-9]{10,25}\b/);
  return generic ? generic[0] : "Not detected";
}
function makeIndicators(text, amount, date, reference) {
  const indicators = [];
  const paid = /\b(successful|success|paid|completed|transaction successful)\b/i.test(text);
  const failed = /\b(failed|failure|declined|pending|processing)\b/i.test(text);
  if (paid && failed) indicators.push({kind:"warn", title:"Mixed status words", body:"The OCR found both positive and negative/pending status terms. Check the original image carefully; OCR can misread text."});
  else if (paid) indicators.push({kind:"ok", title:"Success wording detected", body:"A success-related word is visible. This is only screenshot text and does not confirm settlement."});
  else if (failed) indicators.push({kind:"warn", title:"Pending or failure wording detected", body:"A pending/failure-related word was detected. Confirm the current status in the official app."});
  else indicators.push({kind:"warn", title:"No clear payment status detected", body:"The screenshot text did not clearly contain a common success, pending or failure status."});
  if (amount !== "Not detected") indicators.push({kind:"ok", title:"Amount-like value found", body:`Detected ${amount}. Compare it with the official transaction record.`});
  else indicators.push({kind:"warn", title:"Amount not detected", body:"OCR could not identify an amount confidently. It may be absent, unclear, or written in an unexpected format."});
  if (date !== "Not detected") indicators.push({kind:"ok", title:"Date-like value found", body:`Detected date text: ${date}. Verify it against the official record.`});
  else indicators.push({kind:"warn", title:"Date not detected", body:"No common numeric date format was detected."});
  if (reference !== "Not detected") indicators.push({kind:"ok", title:"Possible reference value found", body:`Candidate: ${reference}. It may not be a real transaction ID; verify it with your bank/UPI app.`});
  else indicators.push({kind:"warn", title:"Reference ID not detected", body:"No likely transaction/reference ID was detected by the basic text rules."});
  indicators.push({kind:"warn", title:"Authenticity is not established", body:"This prototype does not perform forensic image analysis or query a payment provider. It cannot label the screenshot genuine or fake."});
  return indicators;
}
function renderReport(data) {
  $("resultHeadline").textContent = "Review the details before trusting the screenshot";
  $("resultSummary").textContent = "This is an automated text-extraction summary. No live bank or UPI verification was performed.";
  $("detailsGrid").innerHTML = "";
  [["Amount",data.amount],["Date",data.date],["Possible reference",data.reference],["Image file",data.fileName]].forEach(([label,value]) => {
    const card = document.createElement("div"); card.className="detail-card";
    const small=document.createElement("small"); small.textContent=label;
    const strong=document.createElement("strong"); strong.textContent=value;
    card.append(small,strong); $("detailsGrid").append(card);
  });
  $("indicatorList").innerHTML = "";
  data.indicators.forEach(item => {
    const div=document.createElement("div"); div.className=`indicator ${item.kind}`;
    const b=document.createElement("b"); b.textContent=item.title + " — ";
    div.append(b,document.createTextNode(item.body)); $("indicatorList").append(div);
  });
  $("ocrText").textContent = data.text || "No readable text was detected. Try a clearer, higher-resolution image.";
}
$("analyseButton").addEventListener("click", async () => {
  if (!selectedFile) return;
  $("analyseButton").disabled = true;
  setProgress("Preparing image…");
  try {
    if (!window.Tesseract) throw new Error("OCR library did not load. Check your internet connection, then reload the page.");
    setProgress("Reading visible text with OCR. This may take a little while…");
    const result = await Tesseract.recognize(selectedFile, "eng", {
      logger: m => {
        if (m.status === "recognizing text" && typeof m.progress === "number")
          setProgress(`Reading text… ${Math.round(m.progress*100)}%`);
      }
    });
    extractedText = (result.data && result.data.text || "").trim();
    const amount=extractAmount(extractedText), date=extractDate(extractedText), reference=extractReference(extractedText);
    reportData = {fileName:selectedFile.name, amount, date, reference, text:extractedText,
      indicators:makeIndicators(extractedText,amount,date,reference), createdAt:new Date().toISOString()};
    renderReport(reportData);
    setProgress("");
    showScreen(resultScreen);
  } catch (err) {
    setProgress("");
    alert("Analysis could not run: " + (err.message || "Unknown error") + "\n\nCheck your internet connection and reload the page.");
  } finally {
    $("analyseButton").disabled = !selectedFile;
  }
});
$("downloadReport").addEventListener("click", () => {
  if (!reportData) return;
  const report = {
    project: "UPI Shield AI — educational prototype",
    generatedAt: reportData.createdAt,
    fileName: reportData.fileName,
    extracted: {amount:reportData.amount, date:reportData.date, possibleReference:reportData.reference},
    indicators: reportData.indicators,
    ocrText: reportData.text,
    limitation: "This report is not proof of payment or image authenticity. No bank/UPI API was queried."
  };
  const blob = new Blob([JSON.stringify(report,null,2)], {type:"application/json"});
  const url=URL.createObjectURL(blob); const a=document.createElement("a");
  a.href=url; a.download="upi-shield-review-report.json"; a.click(); URL.revokeObjectURL(url);
});
