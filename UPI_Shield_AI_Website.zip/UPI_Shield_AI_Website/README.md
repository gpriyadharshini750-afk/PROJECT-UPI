# UPI Shield AI — Website Prototype

## What's included
- `index.html` — page structure and screens
- `styles.css` — responsive dark navy / teal UI
- `app.js` — page navigation, image upload, browser OCR, simple text extraction, indicators, JSON report download

## Run it without installing Python
1. Extract the ZIP.
2. Open `index.html` in Chrome or Safari while connected to the internet.
3. Click **Get started**, upload a sample/redacted payment screenshot, then click **Analyse screenshot**.
4. If OCR does not load when opened directly, use the free GitHub Pages method below.

## Publish with GitHub Pages (free)
1. Create a new public repository on GitHub (for example `upi-shield-ai`).
2. Upload `index.html`, `styles.css`, and `app.js` to the repository root.
3. Open repository **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site; open the URL shown on that settings page.

## Important limitations
This is a frontend educational prototype. OCR uses Tesseract.js from a CDN, so an internet connection is needed. The app only reads visible text and applies simple keyword/format checks. It does NOT:
- connect to a bank, NPCI, UPI app, payment gateway or transaction API;
- confirm that money was transferred;
- reliably detect manipulated/cropped screenshots or establish image authenticity;
- make a dependable fraud determination.

For a real verification workflow, use an authorized payment provider/bank API and validate server-side transaction status, amount, payee and reference ID. Never treat a screenshot alone as proof of payment. Test with sample or redacted images and do not upload private financial information without permission.
